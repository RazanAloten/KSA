<!DOCTYPE html>
<html>
<head>
    <title>الصفحة الرئيسية</title>
</head>
<body>
    <h1>مرحبًا بك في الصفحة الرئيسية</h1>
    <p><a href="login.html">تسجيل الدخول</a></p>
    <p><a href="signup.html">تسجيل جديد</a></p>
</body>
</html>